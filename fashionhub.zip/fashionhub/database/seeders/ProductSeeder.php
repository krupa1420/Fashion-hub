<?php

namespace Database\Seeders;


use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
         DB::table('products')->insert([
             [
            'name'=>'Kurti',
            "price"=>"300",
            "description"=>"Stylish Kurti For Ladies ",
            "category"=>"Simple Kurti",
            "gallery"=>"https://www.shoutlo.com/uploads/articles/header-img-cotton-kurtis-in-chandigarh-for-summers.jpg"
             ],
             [
            'name'=>'Top',
            "price"=>"400",
            "description"=>"Stylish Crop Tops For Ladies ",
            "category"=>"Top",
            "gallery"=>"https://www.outstandingdef.com/image/catalog/bannerCategory.jpg"
             ],
             [
            'name'=>'Saree',
            "price"=>"500",
            "description"=>"Party wear Saree For Ladies ",
            "category"=>"Saree",
            "gallery"=>"https://frugal2fab.com/2018/05/03/school-farewell-party/#jp-carousel-14768"
             ],
             [
            'name'=>'Jeans',
            "price"=>"600",
            "description"=>"Fancy Jeans",
            "category"=>"Jeans",
            "gallery"=>"https://s4.thingpic.com/images/7i/n4rsXPHx7THt1GVmiq3U6KgX.jpeg"
             ]
        ]);
    }
}
