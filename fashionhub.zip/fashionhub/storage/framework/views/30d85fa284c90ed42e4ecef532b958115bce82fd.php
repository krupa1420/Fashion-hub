
<?php $__env->startSection('content'); ?>
<div class="custom-product">
 <div class="col-sm-10">

       <table class="table">
    
    <tbody>
      <tr>
        <td>Amount</td>
        <td> Rs <?php echo e($total); ?>.</td>
      </tr>
      <tr>
        <td>Tax</td>
        <td>Rs 0.</td>
      </tr>
      <tr>
        <td>Delivery </td>
        <td>Rs 50.</td>
      </tr>
      <tr>
        <td>Total Amount</td>
        <td>Rs <?php echo e($total+ 50); ?></td>
      </tr>
    </tbody>
  </table> 
  <div>
    <form action="/orderplace" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <textarea name="address" type="email" placeholder="Enter Your address" class="form-control" ></textarea>
    </div>
    <div class="form-group">
        <label for="pwd">Payment Method</label> <br> 
        <input type="radio" value="cash" name="payment"><span>Online Payment</span> <br>
        <input type="radio" value="cash" name="payment"><span>EMI Payment</span> <br>
        <input type="radio" value="cash" name="payment"><span>Payment on Delivery</span> <br>
    </div>
    <button type="submit" class="btn btn-default">Order Now</button>
    </form>
  </div>  
 </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fashionhub\resources\views/ordernow.blade.php ENDPATH**/ ?>