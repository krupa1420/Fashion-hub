<hr style="height:2px;color:blue">
<center>
<div style="clear:both" class="panel panel-default"  >
  <div class="panel-body">
      Info . Support . Marketing
  </div>

  <div class="panel-footer"></div>
  Trerms of Use . Privacy Policy
  &copy &trade &reg 2020 Cpoyrights reserved
</div>
</div>
</center><?php /**PATH C:\xampp\htdocs\fashionhub\resources\views/footer.blade.php ENDPATH**/ ?>